import time
while True:
	print(time.ctime())
	time.sleep(10)
