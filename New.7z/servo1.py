import RPi.GPIO as GPIO
import time

pin = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(pin, GPIO.OUT)
p = GPIO.PWM(pin, 50)
p.start(0)

try:
    p.ChangeDutyCycle(10.0)
    time.sleep(3)
    p.ChangeDutyCycle(7.5) #0
    time.sleep(3)
    p.ChangeDutyCycle(5.0)
    time.sleep(3)
    p.ChangeDutyCycle(2.5)
    time.sleep(3)
except KeyboardInterrupt:
    pass

p.stop()
GPIO.cleanup()
